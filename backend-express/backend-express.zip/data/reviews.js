const reviews = [
    {
      rating: 5,
      comment: 'Awesome product, I love it!',
    },
    {
      rating: 4,
      comment: 'Very good, but shipping was slow.',
    },
    {
      rating: 1,
      comment: 'Did not work out of the box. Returning it.',
    },
  ];
  
  export default reviews;